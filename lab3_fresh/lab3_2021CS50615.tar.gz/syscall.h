// System call numbers
#define SYS_open    1
#define SYS_write   2
#define SYS_close   3
#define SYS_exec    4
#define SYS_set_sched_policy 5
#define SYS_get_sched_policy 6